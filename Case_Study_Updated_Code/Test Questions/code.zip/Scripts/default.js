document.addEventListener('DOMContentLoaded', (event) => {
    // Select all table headers and data cells
    const tableCells = document.querySelectorAll('th, td');
  
    // Iterate over each cell to check the text content length
    tableCells.forEach(cell => {
      if (cell.textContent.length <= 20) {
        // If content length is 20 or less, add the 'center-text' class
        cell.style.textAlign = 'center';
        cell.classList.add('center-text');
      }
    });
  });
  